package simpledb;

import java.io.Serializable;

/**
 * A RecordId is a reference to a specific tuple on a specific page of a
 * specific table.
 */
public class RecordId implements Serializable {

    private static final long serialVersionUID = 1L;

    private final PageId pageId;
    private final int tupleNumber;


    /**
     * Creates a new RecordId referring to the specified PageId and tuple
     * number.
     *
     * @param pageId      the pageid of the page on which the tuple resides
     * @param tupleNumber the tuple number within the page.
     */
    public RecordId(PageId pageId, int tupleNumber) {
        this.pageId = pageId;
        this.tupleNumber = tupleNumber;
    }

    /**
     * @return the tuple number this RecordId references.
     */
    public int tupleno() {
        return tupleNumber;
    }

    /**
     * @return the page id this RecordId references.
     */
    public PageId getPageId() {
        return pageId;
    }

    /**
     * Two RecordId objects are considered equal if they represent the same
     * tuple.
     *
     * @return True if this and o represent the same tuple
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RecordId recordId = (RecordId) o;
        return tupleNumber == recordId.tupleno()
                && pageId.equals(recordId.getPageId());
    }

    /**
     * You should implement the hashCode() so that two equal RecordId instances
     * (with respect to equals()) have the same hashCode().
     *
     * @return An int that is the same for equal RecordId objects.
     */
    @Override
    public int hashCode() {
        // just pick a magic number I prefer 23
        // it's a prime number, also it brings good luck lol
        int hash = 23;
        hash = 31 * hash + tupleNumber;
        hash = 31 * hash + pageId.hashCode();
        return hash;
    }
}
